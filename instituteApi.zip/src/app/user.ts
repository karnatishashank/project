export class User{
    state:string;
    instituteName: string;
    instituteCode:number;
    diseCode: number;
    universityState: string;
    universityName: string;
    setPassword: string;
    confirmPassword: string
}
export class User1{


    studentId:number;
    domicileState:string;
    name:string;
    gender:string;
    mobileNumber:number;
    emailId:string;
    instituteCode:number;
    aadharNumber:number;
    password:string;
    


}
