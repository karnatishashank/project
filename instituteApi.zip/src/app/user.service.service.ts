import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './user';




@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http:HttpClient) { 
    
  }
  baseUrl:string = 'http://192.168.13.94:9090/';
  createUser(user: User){
    return this.http.post(this.baseUrl, user);
  }

  baseUrl1:string = 'http://192.168.13.94:9090/student-registration';
  createUser1(user1: User){
    return this.http.post(this.baseUrl1, user1);
  }
}