import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service.service';


@Component({
  selector: 'app-student-registration',
  templateUrl: './student-registration.component.html',
  styleUrls: ['./student-registration.component.css']
})
export class StudentRegistrationComponent implements OnInit {
  StudentForm:FormGroup;
  submitted: boolean = false;


  constructor(private formBuilder: FormBuilder, private router: Router, 
    private userService: UserService) { }



  
    ngOnInit() {
      this.StudentForm = this.formBuilder.group({
        studentId:[''],
        domicileState: [''],
        Name:[''],
        gender: [''],
        mobileNumber: [''],
        emailId: [''],
        institutecode: [''],
        aadharNumber: [''],
        password: ['']
      
      });

}
onInSubmit(){
  this.submitted = true;
    if(this.StudentForm.invalid){
      return;
    }
    this.userService.createUser1(this.StudentForm.value)
      .subscribe( data => {
        this.router.navigate(['registration']);
        alert("student is added");
      });
}
}