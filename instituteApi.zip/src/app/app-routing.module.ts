import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SuccessPageComponent } from './success-page/success-page.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { StudentRegistrationComponent } from './student-registration/student-registration.component';


const routes: Routes = [
  {path: 'Success-page', component: SuccessPageComponent},
  {path: 'registration', component: RegistrationComponent},
  {path: 'login', component:LoginComponent},
  {path: 'student-registration',component:StudentRegistrationComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
