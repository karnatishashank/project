package com.lti.model;

public class Nodal {
	
	private int nodalId;
	private String password;
	public Nodal() {
		super();
	}
	public Nodal(int nodalId, String password) {
		super();
		this.nodalId = nodalId;
		this.password = password;
	}
	public int getNodalId() {
		return nodalId;
	}
	public void setNodalId(int nodalId) {
		this.nodalId = nodalId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	

}
