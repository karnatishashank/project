package com.lti.controller;

import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Institute;
import com.lti.model.Student;
import com.lti.service.InstituteService;

@RestController
@RequestMapping(path = "/123")
@CrossOrigin


public class StudentRestController {

	@Autowired
	private InstituteService service;




@RequestMapping(path="/456",method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<String> addStudent(@RequestBody Student student) {
	ResponseEntity<String> response;
	boolean result=service.addStudent(student);
	if(result){
		response=new ResponseEntity<String>("Student  is added",HttpStatus.CREATED);
	}else{
		response=new ResponseEntity<String>("Student is not added",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	return response;
}
}















