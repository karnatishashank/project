package com.lti.dao;

import com.lti.model.Institute;
import com.lti.model.Student;

public interface InstituteDao {
	public int createInstitute(Institute institute);
	public int createStudents(Student student);
	
}
